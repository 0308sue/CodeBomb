/*
 * screen_arrays.h - Sumin's array module with the code editor built in
 * screen_arrays.h - 코드 에디터가 들어간 수민의 배열 모듈
 *
 * Modes / 모드:
 *   Write code   - the player writes C; the trace plays on the cards (NEW)
 *                  플레이어가 C를 작성하고 실행 기록이 카드에 재생됨 (새 기능)
 *   Predict      - Sumin's quiz mode            / 수민의 퀴즈 모드
 *   Explore      - Sumin's sample comparisons   / 수민의 샘플 비교
 *   Find the bug - Sumin's bounds mission       / 수민의 범위 오류 미션
 */
#ifndef SCREEN_ARRAYS_H
#define SCREEN_ARRAYS_H

#include "editor_ui.h"

#include <stdbool.h>

typedef struct ArraysScreen ArraysScreen;

ArraysScreen *arrays_create(const EditorStyle *style);
void          arrays_destroy(ArraysScreen *s);

/* Keyboard, editor input and timers. Call before arrays_draw().
 * 키보드, 에디터 입력, 타이머. arrays_draw()보다 먼저 호출. */
void arrays_update(ArraysScreen *s, float dt);

/* Draw the whole canvas; buttons are handled while drawing (Sumin's
 * immediate-mode style).
 * 전체 화면을 그린다. 버튼은 그리면서 처리한다 (수민의 즉시 모드 방식). */
void arrays_draw(ArraysScreen *s);

/* True while the code editor has keyboard focus.
 * 코드 에디터가 키보드 포커스를 가진 동안 true. */
bool arrays_typing(const ArraysScreen *s);

/* Called when another screen is opened. / 다른 화면을 열 때 호출. */
void arrays_leave(ArraysScreen *s);

/* Scripted state for screenshots (--shot). mode: "code", "predict",
 * "explore", "bug". variant: code mode 0 = example solution,
 * 1 = bounds bug, 2 = compile error, 3 = starter code.
 * 스크린샷(--shot)용 상태 설정. */
void arrays_qa(ArraysScreen *s, const char *mode, int level, int steps,
               int variant);

#endif
