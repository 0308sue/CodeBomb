/*
 * screen_arrays.c - Sumin's array module (main_SOO.c) at 1920 x 1200, with
 * the code editor in the "Write code" mode
 * screen_arrays.c - 1920 x 1200으로 옮긴 수민의 배열 모듈 (main_SOO.c)과
 * "Write code" 모드의 코드 에디터
 *
 * Predict, Explore and Find the bug keep Sumin's logic; only positions and
 * font sizes changed. In Write code the mission stays at the top right, the
 * editor replaces the sample code below it, and the cards on the left show
 * the player's own reads and writes (the plan in her report of 10 Nov).
 * Predict, Explore, Find the bug은 수민의 로직을 그대로 두고 위치와 글자
 * 크기만 바꿨다. Write code에서는 미션이 오른쪽 위에 그대로 있고, 에디터가
 * 그 아래의 샘플 코드를 대신하며, 왼쪽 카드는 플레이어 코드의 읽기와
 * 쓰기를 보여 준다 (수민의 11월 10일 보고서 계획).
 */
#include "screen_arrays.h"

#include "array_bridge.h"
#include "compiler.h"
#include "editor.h"
#include "quiz_SOO.h"
#include "ui.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { MODE_CODE, MODE_PREDICT, MODE_EXPLORE, MODE_BUG } ArraysMode;

/* ---- layout (1920 x 1200) / 화면 배치 ------------------------------------ */
static const Rectangle LEFT  = { 30, 264, 1120, 800 };
static const Rectangle RIGHT = { 1174, 264, 716, 800 };
#define LX    57                       /* left panel content x  / 왼쪽 내용 x  */
#define LW    1066                     /* left panel content w  / 왼쪽 내용 폭 */
#define RX    1201                     /* right panel content x / 오른쪽 내용 x */
#define RW    662                      /* right panel content w / 오른쪽 내용 폭 */
#define ROW_Y 1082                     /* bottom button row     / 아래 버튼 줄  */
#define ROW_H 56
#define FOOT_Y 1160                    /* key hints             / 키 안내      */

static const float SPEEDS[3] = { 0.45f, 0.15f, 0.05f };   /* Sumin's S key */
static const char *const SPEED_NAMES[3] = { "Slow", "Normal", "Fast" };

struct ArraysScreen {
    ArraysMode mode;
    int        level;
    bool       completed[SOO_LEVEL_COUNT];
    float      interval;

    /* Sumin's sample playback (her App struct) / 수민의 샘플 재생 */
    SooState    state;
    SooEvent    trace[SOO_MAX_EVENTS];
    int         count, cursor;
    SooScenario scenario;
    bool        playing;
    int         answer;
    float       timer;

    /* Write code mode / 코드 작성 모드 */
    Editor            *ed;
    const EditorStyle *style;
    char              *code[SOO_LEVEL_COUNT];  /* saved per level / 레벨별 저장 */
    Program           *prog;
    VM                *vm;
    ArrayTrace        *ctrace;
    SooState           cstate;
    int                ccursor;
    bool               cplaying;
    float              ctimer;
    bool               compiled_ok;
    bool               have_trace;
    unsigned           compiled_version;
    unsigned           seen_version;
    CompileResult      compile;
    char               note[256];
};

/* ========================================================================
 * Sumin's sample logic (unchanged behaviour) / 수민의 샘플 로직 (동작 동일)
 * ====================================================================== */

static void Load(ArraysScreen *a)
{
    SooReset(&a->state, &SOO_LEVELS[a->level]);
    a->count = SooBuildSample(a->state.level, a->scenario, a->trace,
                              SOO_MAX_EVENTS);
    a->cursor = 0;
    a->timer = 0;
    a->playing = false;
    a->answer = -1;
    if (a->count < 0) {
        a->count = 0;
        a->state.status = SOO_FAILURE;
    }
}

static bool quiz(const ArraysScreen *a)
{
    return a->mode == MODE_PREDICT || a->mode == MODE_BUG;
}

static void Step(ArraysScreen *a)
{
    if (a->cursor >= a->count || a->state.status >= SOO_SUCCESS) {
        a->playing = false;
        return;
    }
    SooApplyEvent(&a->state, a->trace[a->cursor++]);
    bool debug = a->mode == MODE_BUG;
    if (a->state.status == SOO_SUCCESS && a->scenario == SOO_CORRECT &&
        (!quiz(a) || (debug ? a->answer == 1
                            : a->answer == SOO_QUIZZES[a->level].answer)))
        a->completed[a->level] = true;
    if (a->state.status >= SOO_SUCCESS || a->cursor >= a->count)
        a->playing = false;
}

static void Back(ArraysScreen *a)
{
    int target = a->cursor > 0 ? a->cursor - 1 : 0;
    SooReset(&a->state, &SOO_LEVELS[a->level]);
    a->cursor = 0;
    a->playing = false;
    a->timer = 0;
    while (a->cursor < target) Step(a);
}

static void Answer(ArraysScreen *a, int choice)
{
    if (!quiz(a) || a->answer >= 0 || choice < 0 || choice > 2) return;
    a->answer = choice;
    a->playing = true;
    a->timer = 0;
}

static void CompareBounds(ArraysScreen *a, SooScenario scenario)
{
    int answer = a->answer;
    a->scenario = scenario;
    Load(a);
    a->answer = answer;
    a->playing = true;
}

/* ========================================================================
 * Write code mode / 코드 작성 모드
 * ====================================================================== */

static const SooLevel *cur_level(const ArraysScreen *s)
{
    return &SOO_LEVELS[s->level];
}

/* Names to colour as built-ins: the level's array and constants.
 * 내장 이름으로 색칠할 것: 레벨의 배열과 상수. */
static void code_set_known(ArraysScreen *s)
{
    static const char *const one_d[] = { "cards", "N" };
    static const char *const two_d[] = { "grid", "ROWS", "COLS" };
    if (cur_level(s)->rows == 1) ed_set_known(s->ed, one_d, 2);
    else ed_set_known(s->ed, two_d, 3);
}

static void code_clear_run(ArraysScreen *s)
{
    s->have_trace = false;
    s->compiled_ok = true;
    s->cplaying = false;
    s->ccursor = 0;
    s->ctimer = 0;
    s->note[0] = '\0';
    SooReset(&s->cstate, cur_level(s));
}

/* Put the level's saved code in the editor, cursor inside run().
 * 레벨에 저장된 코드를 에디터에 넣고 커서를 run() 안에 둔다. */
static void code_load_level(ArraysScreen *s)
{
    ed_set_text(s->ed, s->code[s->level], false);
    const char *body = strstr(s->ed->text, "{\n");
    int pos = body ? (int)(body - s->ed->text) + 2 : 0;
    while (pos < s->ed->len && s->ed->text[pos] == ' ') pos++;
    ed_set_cursor(s->ed, pos, false);
    code_set_known(s);
    code_clear_run(s);
    s->seen_version = s->ed->version;
    s->compiled_version = s->ed->version - 1;   /* not compiled yet
                                                   아직 컴파일 안 됨 */
}

static void code_save_level(ArraysScreen *s)
{
    memcpy(s->code[s->level], s->ed->text, (size_t)s->ed->len + 1);
}

static bool code_fresh(const ArraysScreen *s)
{
    return s->have_trace && s->ed->version == s->compiled_version;
}

static int code_length(const ArraysScreen *s)
{
    return s->have_trace ? array_trace_length(s->ctrace) : 0;
}

static bool code_done(const ArraysScreen *s)
{
    return s->cstate.status >= SOO_SUCCESS || s->ccursor >= code_length(s);
}

/* Compile and record if the code changed since the last run.
 * 마지막 실행 이후 코드가 바뀌었으면 컴파일하고 기록한다. */
static bool code_prepare(ArraysScreen *s)
{
    if (code_fresh(s)) return true;
    code_clear_run(s);
    prog_init(s->prog);
    array_register_level(s->prog, cur_level(s));
    s->compiled_version = s->ed->version;
    s->compiled_ok = compile_program(s->ed->text, s->ed->len, s->prog,
                                     &s->compile);
    if (!s->compiled_ok) {
        snprintf(s->note, sizeof s->note, "Line %d, column %d: %.200s",
                 s->compile.line, s->compile.col, s->compile.message);
        return false;
    }
    array_record(s->ctrace, s->prog, cur_level(s), s->vm);
    s->have_trace = true;
    snprintf(s->cstate.message, sizeof s->cstate.message,
             "Compiled. %d step%s recorded. Watch them play on the cards.",
             code_length(s), code_length(s) == 1 ? "" : "s");
    return true;
}

static void code_step(ArraysScreen *s)
{
    if (array_playback_step(s->ctrace, &s->cstate, &s->ccursor) &&
        s->cstate.status == SOO_SUCCESS)
        s->completed[s->level] = true;
    if (code_done(s)) s->cplaying = false;
}

static void code_run(ArraysScreen *s)
{
    if (s->cplaying) {
        s->cplaying = false;
        return;
    }
    if (!code_prepare(s)) return;
    if (code_done(s)) array_playback_to(s->ctrace, &s->cstate, &s->ccursor, 0);
    s->cplaying = true;
    s->ctimer = s->interval;          /* first step right away / 첫 단계 즉시 */
}

static void code_step_key(ArraysScreen *s)
{
    s->cplaying = false;
    if (!code_prepare(s)) return;
    code_step(s);
}

static void code_back(ArraysScreen *s)
{
    if (!code_fresh(s) || s->ccursor == 0) return;
    s->cplaying = false;
    array_playback_to(s->ctrace, &s->cstate, &s->ccursor, s->ccursor - 1);
}

static void code_reset(ArraysScreen *s)
{
    s->cplaying = false;
    s->ccursor = 0;
    SooReset(&s->cstate, cur_level(s));
    if (code_fresh(s))
        snprintf(s->cstate.message, sizeof s->cstate.message,
                 "Back to the start. Press Run or Step to replay.");
}

/* Editing the code stops a replay: the trace no longer matches the text.
 * 코드를 고치면 재생을 멈춘다: 기록이 더 이상 텍스트와 맞지 않는다. */
static void code_watch_edits(ArraysScreen *s)
{
    if (s->ed->version == s->seen_version) return;
    s->seen_version = s->ed->version;
    if (s->have_trace && (s->ccursor > 0 || s->cplaying)) {
        s->cplaying = false;
        s->ccursor = 0;
        SooReset(&s->cstate, cur_level(s));
        snprintf(s->note, sizeof s->note,
                 "Code changed. Press Run to compile and try it again.");
    }
}

static void code_update_markers(ArraysScreen *s)
{
    Editor *ed = s->ed;
    ed->exec_line = ed->error_line = ed->error_col = ed->error_len = 0;
    if (!s->compiled_ok && ed->version == s->compiled_version) {
        ed->error_line = s->compile.line;
        ed->error_col = s->compile.col;
        ed->error_len = s->compile.len;
    } else if (code_fresh(s) && s->ccursor > 0) {
        int line = array_line_at(s->ctrace, s->ccursor);
        if (s->cstate.status == SOO_FAILURE) ed->error_line = line;
        else if (s->cstate.status != SOO_SUCCESS) ed->exec_line = line;
    }
}

/* Editor rectangle under the mission text (depends on its length).
 * 미션 텍스트 아래의 에디터 영역 (텍스트 길이에 따라 달라짐). */
static Rectangle code_editor_rect(const ArraysScreen *s)
{
    int y = 290 + ui_line_height(FS_SMALL);
    y += ui_wrapped_height(cur_level(s)->objective, RW, FS_BODY);
    y += 8 + ui_line_height(FS_SMALL) + 12;
    return (Rectangle){ RX, (float)y, RW, RIGHT.y + RIGHT.height - 22 - y };
}

/* ========================================================================
 * Shared drawing / 공용 그리기
 * ====================================================================== */

static void CardFace(int x, int y, bool fault)
{
    Color tint = fault ? (Color){ 255, 180, 203, 255 }
                       : (Color){ 165, 244, 207, 255 };
    DrawCircle(x - 8, y, 3, tint);
    DrawCircle(x + 8, y, 3, tint);
    DrawLineEx((Vector2){ x - 5, y + 8 }, (Vector2){ x, y + (fault ? 4 : 11) },
               2.0f, tint);
    DrawLineEx((Vector2){ x, y + (fault ? 4 : 11) }, (Vector2){ x + 5, y + 8 },
               2.0f, tint);
}

/* Sumin's Cards(), 1.5x. Values, labels and targets don't rely on colour.
 * 수민의 Cards(), 1.5배. 값, 라벨, 목표가 색에만 의존하지 않는다. */
static void Cards(const SooState *st)
{
    const SooLevel *l = st->level;
    int cell = l->cols > 8 ? 96 : l->rows > 1 ? 124 : 120, gap = 14;
    int left = LX + (LW - l->cols * (cell + gap) + gap) / 2;
    int top = l->rows > 1 ? 394 : 529;
    for (int r = 0; r < l->rows; r++)
        for (int c = 0; c < l->cols; c++) {
            int k = r * l->cols + c;
            int x = left + c * (cell + gap), y = top + r * (cell + gap);
            bool active = st->active_row == r && st->active_col == c;
            bool fault = st->cells[k] != 0;
            DrawRectangleRounded((Rectangle){ x, y, cell, cell }, 0.12f, 6,
                                 fault ? UI_FAULT : UI_SAFE);
            if (active)
                DrawRectangleRoundedLinesEx(
                    (Rectangle){ x - 5, y - 5, cell + 10, cell + 10 }, 0.12f,
                    6, 4.0f, UI_ACCENT);
            DrawText(l->rows == 1 ? TextFormat("[%d]", c)
                                  : TextFormat("[%d][%d]", r, c),
                     x + 9, y + 9, FS_SMALL, WHITE);
            /* 2D cards show "to N" at the top right, so the value moves a
             * little left and down to keep clear of it. 1D cards have a
             * short index, so the face fits in the top-right corner.
             * 2D 카드는 오른쪽 위에 "to N"이 있으므로 값을 조금 왼쪽 아래로
             * 옮긴다. 1D 카드는 인덱스가 짧아 얼굴이 오른쪽 위에 들어간다. */
            const char *v = TextFormat("%d", st->cells[k]);
            bool two_d = l->rows > 1;
            DrawText(v, x + (cell - MeasureText(v, FS_TITLE)) / 2 - (two_d ? 12 : 0),
                     y + cell / 2 - (two_d ? 12 : 18), FS_TITLE, WHITE);
            DrawText(fault ? "FAULT" : "SAFE", x + 9, y + cell - 28, FS_SMALL,
                     WHITE);
            if (two_d) CardFace(x + cell - 20, y + cell - 22, fault);
            else CardFace(x + cell - 22, y + 18, fault);
            if (l->rows == 1)
                DrawText(TextFormat("to %d", l->goal[k]), x + 9, y + cell + 14,
                         FS_SMALL, UI_MUTED);
            else
                ui_text_right(TextFormat("to %d", l->goal[k]), x + cell - 9,
                              y + 36, FS_SMALL, WHITE);
        }
}

/* "i = 0   j = 2" with "--" for unset values (Sumin's format).
 * 값이 없으면 "--" (수민의 형식). */
static const char *ij_text(const SooState *st)
{
    static char buf[48];
    char iv[12], jv[12];
    if (st->i < 0) snprintf(iv, sizeof iv, "--");
    else snprintf(iv, sizeof iv, "%d", st->i);
    if (st->j < 0) snprintf(jv, sizeof jv, "--");
    else snprintf(jv, sizeof jv, "%d", st->j);
    snprintf(buf, sizeof buf, "i = %s   j = %s", iv, jv);
    return buf;
}

static void ops_bar(const SooState *st, int x, int y, int w)
{
    int budget = st->level->budget;
    DrawRectangle(x, y, w, 12, UI_BAR_BG);
    int filled = budget > 0 ? (int)((float)w * st->operations / budget) : 0;
    if (filled > w) filled = w;
    DrawRectangle(x, y, filled, 12,
                  st->operations >= budget ? UI_FAULT : UI_ACCENT);
}

static Color status_color(SooStatus st)
{
    return st == SOO_FAILURE ? UI_ERROR : st == SOO_SUCCESS ? UI_SUCCESS
                                                            : UI_INK;
}

static void left_panel(const SooState *st, const char *heading, Color hcol,
                       const char *message)
{
    const SooLevel *l = st->level;
    ui_panel(LEFT);
    DrawText(l->title, LX, 282, FS_BODY, UI_INK);
    DrawText(l->concept, LX, 324, FS_SMALL, UI_ACCENT);
    Cards(st);
    if (l->rows != 4)
        DrawText("0 = SAFE   1 = FAULT   to = TARGET   blue outline = accessed "
                 "card", LX, 1022, FS_SMALL, UI_MUTED);
    int log_y = l->rows == 4 ? 958 : l->rows > 1 ? 849 : 790;
    DrawText(heading, LX, log_y, FS_SMALL, hcol);
    ui_wrapped(message, LX, log_y + 30, LW, FS_SMALL, hcol);
}

/* ========================================================================
 * Right panels / 오른쪽 패널
 * ====================================================================== */

static int mission_text(const char *text)
{
    DrawText("MISSION", RX, 290, FS_SMALL, UI_ACCENT);
    return ui_wrapped(text, RX, 290 + ui_line_height(FS_SMALL), RW, FS_BODY,
                      UI_INK);
}

static int choice_buttons(ArraysScreen *a, int y, const char *const labels[3])
{
    int w = (RW - 2 * 14) / 3;
    for (int n = 0; n < 3; n++)
        if (ui_button((Rectangle){ RX + n * (w + 14), y, w, 60 }, labels[n],
                      a->answer < 0, a->answer == n))
            Answer(a, n);
    return y + 60;
}

static void DrawQuiz(ArraysScreen *a)
{
    const SooQuiz *q = &SOO_QUIZZES[a->level];
    int y = mission_text(cur_level(a)->objective) + 20;
    DrawText("READ THE CODE", RX, y, FS_SMALL, UI_ACCENT);
    y = ui_lines(SooSampleCode(a->state.level, SOO_CORRECT), RX, y + 34,
                 FS_SMALL, UI_INK) + 20;
    y = ui_wrapped(q->question, RX, y, RW, FS_BODY, UI_INK) + 12;
    char labels[3][50];
    const char *ptrs[3];
    for (int n = 0; n < 3; n++) {
        snprintf(labels[n], sizeof labels[n], "%c  %s", 'A' + n, q->choices[n]);
        ptrs[n] = labels[n];
    }
    y = choice_buttons(a, y, ptrs) + 20;
    if (a->answer < 0) {
        DrawText("Choose A, B or C to reveal the trace.", RX, y, FS_SMALL,
                 UI_MUTED);
    } else {
        bool correct = a->answer == q->answer;
        DrawText(correct ? "Correct!"
                         : TextFormat("Not quite. Answer: %c", 'A' + q->answer),
                 RX, y, FS_BODY, correct ? UI_ACCENT : UI_ERROR);
        ui_wrapped(q->reason, RX, y + 44, RW, FS_SMALL, UI_INK);
        DrawText(TextFormat("%s   |   Memory ops: %d / %d", ij_text(&a->state),
                            a->state.operations, cur_level(a)->budget),
                 RX, 1022, FS_SMALL, UI_MUTED);
    }
}

static void DrawBounds(ArraysScreen *a)
{
    bool fixed = a->scenario == SOO_CORRECT;
    int y = mission_text("Fix the loop so it checks all 8 cards without going "
                         "out of bounds.") + 20;
    DrawText(fixed ? "FIXED SAMPLE" : "ORIGINAL SAMPLE", RX, y, FS_SMALL,
             UI_ACCENT);
    y = ui_lines(TextFormat("for (int i = 0; i %s 8; ++i) {\n"
                            "    if (cards[i] == 1)\n"
                            "        cards[i] = 0;\n}",
                            fixed ? "<" : "<="),
                 RX, y + 34, FS_BODY, UI_INK) + 16;
    y = ui_wrapped("Which loop condition visits all 8 cards safely?", RX, y, RW,
                   FS_BODY, UI_INK) + 12;
    static const char *const choices[3] = { "A  i <= 8", "B  i < 8",
                                            "C  i < 7" };
    y = choice_buttons(a, y, choices) + 20;
    if (a->answer < 0) {
        DrawText("Choose A, B or C.", RX, y, FS_SMALL, UI_MUTED);
        return;
    }
    DrawText(a->answer == 1 ? "Correct: i < 8" : "Not quite. Use i < 8.", RX, y,
             FS_BODY, a->answer == 1 ? UI_ACCENT : UI_ERROR);
    ui_wrapped(a->answer == 2 ? "i < 7 skips card 7. i < 8 visits indices 0 to 7."
                              : "Eight cards use indices 0 to 7. i <= 8 tries "
                                "to read card 8.",
               RX, y + 44, RW, FS_SMALL, UI_INK);
    DrawText(TextFormat("Step %d / %d   |   i = %s", a->cursor, a->count,
                        a->state.i < 0 ? "--" : TextFormat("%d", a->state.i)),
             RX, 1022, FS_SMALL, UI_MUTED);
    if (ui_button((Rectangle){ 52, ROW_Y, 330, ROW_H }, "Run original", true,
                  !fixed))
        CompareBounds(a, SOO_BOUNDS);
    if (ui_button((Rectangle){ 400, ROW_Y, 330, ROW_H }, "Run fix", true, fixed))
        CompareBounds(a, SOO_CORRECT);
}

static void DrawExplore(ArraysScreen *a)
{
    const SooLevel *l = cur_level(a);
    int y = mission_text(l->objective) + 24;
    DrawText(ij_text(&a->state), RX, y, FS_BODY, UI_INK);
    y += 50;
    DrawText(TextFormat("MEMORY OPS  %d / %d", a->state.operations, l->budget),
             RX, y, FS_BODY, UI_INK);
    ops_bar(&a->state, RX, y + 46, RW - 40);
    y += 86;
    DrawText("REFERENCE TRACE / NOT EDITABLE", RX, y, FS_SMALL, UI_MUTED);
    ui_lines(SooSampleCode(l, a->scenario), RX, y + 40, FS_SMALL, UI_INK);
    DrawText(TextFormat("Trace step %d / %d", a->cursor, a->count), RX, 984,
             FS_SMALL, UI_MUTED);
    DrawText("Read/write = 1 op. Loop update = 0.", RX, 1022, FS_SMALL,
             UI_MUTED);
    static const char *const scenarios[4] = { "Correct", "Missing step",
                                              "Out of bounds",
                                              "Repeated scans" };
    DrawText("COMPARE", 52, ROW_Y + 18, FS_SMALL, UI_MUTED);
    for (int n = 0; n < 4; n++)
        if (ui_button((Rectangle){ 190 + n * 240, ROW_Y, 226, ROW_H },
                      scenarios[n], true, a->scenario == (SooScenario)n)) {
            a->scenario = (SooScenario)n;
            Load(a);
        }
}

static void DrawCode(ArraysScreen *a)
{
    const SooLevel *l = cur_level(a);
    int y = mission_text(l->objective) + 8;
    char tools[96];
    array_tools_text(l, tools, sizeof tools);
    DrawText(TextFormat("You can use   %s", tools), RX, y, FS_SMALL, UI_MUTED);
    editor_ui_draw(a->ed, code_editor_rect(a), a->style);
}

/* ========================================================================
 * Screen / 화면
 * ====================================================================== */

static void set_mode(ArraysScreen *a, ArraysMode mode)
{
    if (a->mode == mode) return;
    if (a->mode == MODE_CODE) {
        a->cplaying = false;
        a->ed->focused = false;
    }
    a->mode = mode;
    a->playing = false;
    if (mode == MODE_BUG) {
        a->level = 1;
        a->scenario = SOO_BOUNDS;
    } else {
        a->scenario = SOO_CORRECT;
    }
    if (mode == MODE_CODE) {
        code_load_level(a);
        a->ed->focused = true;
    }
    Load(a);
}

static void set_level(ArraysScreen *a, int level)
{
    if (level == a->level || level < 0 || level >= SOO_LEVEL_COUNT) return;
    if (a->mode == MODE_CODE) code_save_level(a);
    a->level = level;
    if (a->mode == MODE_CODE) {
        code_load_level(a);
        a->ed->focused = true;
    }
    Load(a);
}

ArraysScreen *arrays_create(const EditorStyle *style)
{
    ArraysScreen *a = calloc(1, sizeof *a);
    if (!a) return NULL;
    a->ed = calloc(1, sizeof *a->ed);
    a->prog = calloc(1, sizeof *a->prog);
    a->vm = calloc(1, sizeof *a->vm);
    a->ctrace = calloc(1, sizeof *a->ctrace);
    bool ok = a->ed && a->prog && a->vm && a->ctrace;
    for (int n = 0; n < SOO_LEVEL_COUNT && ok; n++) {
        a->code[n] = calloc(1, ED_MAX_TEXT);
        if (!a->code[n]) ok = false;
        else array_starter_code(&SOO_LEVELS[n], a->code[n], ED_MAX_TEXT);
    }
    if (!ok) {
        arrays_destroy(a);
        return NULL;
    }
    a->style = style;
    a->interval = SPEEDS[0];
    a->mode = MODE_CODE;
    ed_init(a->ed);
    code_load_level(a);
    a->ed->focused = true;
    Load(a);
    return a;
}

void arrays_destroy(ArraysScreen *a)
{
    if (!a) return;
    for (int n = 0; n < SOO_LEVEL_COUNT; n++) free(a->code[n]);
    free(a->ctrace);
    free(a->vm);
    free(a->prog);
    free(a->ed);
    free(a);
}

bool arrays_typing(const ArraysScreen *a)
{
    return a->mode == MODE_CODE && a->ed->focused;
}

void arrays_leave(ArraysScreen *a)
{
    a->playing = false;
    a->cplaying = false;
    a->ed->focused = false;
    if (a->ed->ibeam) {
        SetMouseCursor(MOUSE_CURSOR_DEFAULT);
        a->ed->ibeam = false;
    }
}

static bool cmd_down(void)
{
    return IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL) ||
           IsKeyDown(KEY_LEFT_SUPER) || IsKeyDown(KEY_RIGHT_SUPER);
}

static void cycle_speed(ArraysScreen *a)
{
    a->interval = a->interval > 0.3f ? 0.15f : a->interval > 0.1f ? 0.05f
                                                                  : 0.45f;
}

void arrays_update(ArraysScreen *a, float dt)
{
    bool typing = arrays_typing(a);

    if (a->mode == MODE_CODE) {
        editor_ui_update(a->ed, code_editor_rect(a), a->style);
        code_watch_edits(a);
        typing = arrays_typing(a);

        /* Function keys work even while typing (F5 = run, like IDEs).
         * 기능 키는 입력 중에도 동작한다 (IDE처럼 F5 = 실행). */
        if (IsKeyPressed(KEY_F5) || (cmd_down() && IsKeyPressed(KEY_ENTER)))
            code_run(a);
        if (IsKeyPressed(KEY_F6)) code_step_key(a);
        if (IsKeyPressed(KEY_F7)) code_back(a);
        if (IsKeyPressed(KEY_F8)) code_reset(a);
        if (!typing) {
            if (IsKeyPressed(KEY_SPACE)) code_run(a);
            if (IsKeyPressed(KEY_RIGHT)) code_step_key(a);
            if (IsKeyPressed(KEY_LEFT)) code_back(a);
            if (IsKeyPressed(KEY_R)) code_reset(a);
        }
        if (a->cplaying) {
            a->ctimer += dt;
            if (a->ctimer >= a->interval) {
                a->ctimer = 0;
                code_step(a);
            }
        }
        code_update_markers(a);
    } else {
        /* Sumin's keys / 수민의 키 */
        if (IsKeyPressed(KEY_R)) {
            if (a->mode == MODE_BUG) a->scenario = SOO_BOUNDS;
            Load(a);
        }
        if (IsKeyPressed(KEY_A)) Answer(a, 0);
        if (IsKeyPressed(KEY_B)) Answer(a, 1);
        if (IsKeyPressed(KEY_C)) Answer(a, 2);
        bool revealed = !quiz(a) || a->answer >= 0;
        if (revealed && IsKeyPressed(KEY_SPACE) &&
            a->state.status < SOO_SUCCESS)
            a->playing = !a->playing;
        if (revealed && IsKeyPressed(KEY_RIGHT)) {
            a->playing = false;
            Step(a);
        }
        if (revealed && IsKeyPressed(KEY_LEFT)) Back(a);
        if (a->playing) {
            a->timer += dt;
            if (a->timer >= a->interval) {
                a->timer = 0;
                Step(a);
            }
        }
    }

    if (!typing) {
        for (int n = 0; n < SOO_LEVEL_COUNT; n++)
            if (a->mode != MODE_BUG && IsKeyPressed(KEY_ONE + n)) set_level(a, n);
        if (IsKeyPressed(KEY_S)) cycle_speed(a);
    }
}

static void draw_header_buttons(ArraysScreen *a)
{
    static const char *const names[4] = { "Write code", "Predict", "Explore",
                                          "Find the bug" };
    for (int n = 0; n < 4; n++)
        if (ui_button((Rectangle){ 1030 + n * 214, 98, 200, 52 }, names[n],
                      true, a->mode == (ArraysMode)n))
            set_mode(a, (ArraysMode)n);

    for (int n = 0; n < SOO_LEVEL_COUNT; n++) {
        char label[32];
        snprintf(label, sizeof label, "%d  %s", n + 1,
                 a->completed[n] ? "DEFUSED" : "LEVEL");
        if (ui_button((Rectangle){ 30 + n * 313, 180, 297, 66 }, label,
                      a->mode != MODE_BUG, a->level == n))
            set_level(a, n);
    }
}

static void draw_code_mode(ArraysScreen *a)
{
    const SooState *st = &a->cstate;
    const char *heading;
    Color hcol;
    const char *message;
    bool compile_error = !a->compiled_ok &&
                         a->ed->version == a->compiled_version;

    if (compile_error) {
        heading = "COMPILE ERROR";
        hcol = UI_ERROR;
        message = a->note;
    } else if (code_fresh(a) && a->ccursor > 0) {
        heading = st->status == SOO_SUCCESS   ? "DEFUSED"
                : st->status == SOO_FAILURE   ? "SIGNAL FAILED"
                                              : "EXECUTION LOG";
        hcol = status_color(st->status);
        message = st->message;
    } else if (code_fresh(a)) {
        heading = "READY";
        hcol = UI_INK;
        message = st->message;
    } else {
        heading = "WRITE YOUR CODE";
        hcol = UI_INK;
        message = a->note[0] ? a->note
                             : "Write C in the editor, then press Run (F5). "
                               "Each read and write in your code plays out on "
                               "the cards, one step at a time.";
    }
    left_panel(st, heading, hcol, message);

    /* i/j, memory budget and step count in the left panel's corner.
     * 왼쪽 패널 모서리에 i/j, 메모리 예산, 단계 수. */
    int sx = (int)(LEFT.x + LEFT.width) - 27;
    ui_text_right(ij_text(st), sx, 282, FS_BODY, UI_INK);
    ui_text_right(TextFormat("MEMORY OPS  %d / %d", st->operations,
                             st->level->budget),
                  sx, 324, FS_SMALL, UI_INK);
    ops_bar(st, sx - 380, 352, 380);
    if (code_fresh(a))
        ui_text_right(TextFormat("Step %d / %d", a->ccursor, code_length(a)),
                      sx - 400, 324, FS_SMALL, UI_MUTED);

    ui_panel(RIGHT);
    DrawCode(a);

    /* Speed (Sumin's S key values) / 속도 (수민의 S 키 값) */
    DrawText("SPEED", 52, ROW_Y + 18, FS_SMALL, UI_MUTED);
    for (int n = 0; n < 3; n++)
        if (ui_button((Rectangle){ 160 + n * 170, ROW_Y, 156, ROW_H },
                      SPEED_NAMES[n], true, a->interval == SPEEDS[n])) {
            a->interval = SPEEDS[n];
            a->ed->focused = true;
        }

    float bw = (RIGHT.width - 3 * 14) / 4;
    bool can_step = !code_fresh(a) || !code_done(a);
    bool control = false;   /* a game control was clicked / 조작 버튼 클릭 */
    if (ui_button((Rectangle){ RIGHT.x, ROW_Y, bw, ROW_H },
                  a->cplaying ? "Pause" : "Run", true, a->cplaying)) {
        code_run(a);
        control = true;
    }
    if (ui_button((Rectangle){ RIGHT.x + (bw + 14), ROW_Y, bw, ROW_H }, "Step",
                  can_step, false)) {
        code_step_key(a);
        control = true;
    }
    if (ui_button((Rectangle){ RIGHT.x + 2 * (bw + 14), ROW_Y, bw, ROW_H },
                  "Back", code_fresh(a) && a->ccursor > 0, false)) {
        code_back(a);
        control = true;
    }
    if (ui_button((Rectangle){ RIGHT.x + 3 * (bw + 14), ROW_Y, bw, ROW_H },
                  "Reset", true, false)) {
        code_reset(a);
        control = true;
    }
    /* Clicking Run/Step/... keeps the editor focused, so the next letters
     * typed go into the code instead of triggering single-key shortcuts.
     * Run/Step 등을 눌러도 에디터 포커스를 유지한다. 그래서 다음에 입력한
     * 글자가 한 글자 단축키 대신 코드에 들어간다. */
    if (control) a->ed->focused = true;

    DrawText("F5 / Ctrl+Enter: run    F6: step    F7: back    F8: reset    "
             "Esc: leave editor    (Mac: Cmd+Enter, fn+F5)",
             45, FOOT_Y, FS_SMALL, UI_MUTED);
}

static void draw_sample_mode(ArraysScreen *a)
{
    bool sample_done = quiz(a) && a->state.status == SOO_SUCCESS;
    const char *heading = sample_done ? "SAMPLE COMPLETE"
                        : a->state.status == SOO_SUCCESS ? "DEFUSED"
                        : a->state.status == SOO_FAILURE ? "SIGNAL FAILED"
                                                         : "EXECUTION LOG";
    const char *message =
        quiz(a) && a->answer < 0
            ? (a->mode == MODE_BUG ? "Find the condition that keeps i inside "
                                     "the array."
                                   : "Read the code and predict what happens.")
        : sample_done ? TextFormat("The sample reached the target in %d "
                                   "operations.", a->state.operations)
                      : a->state.message;
    left_panel(&a->state, heading, status_color(a->state.status), message);

    ui_panel(RIGHT);
    if (a->mode == MODE_BUG) DrawBounds(a);
    else if (a->mode == MODE_PREDICT) DrawQuiz(a);
    else DrawExplore(a);

    bool revealed = !quiz(a) || a->answer >= 0;
    bool live = revealed && a->state.status < SOO_SUCCESS;
    if (a->mode == MODE_PREDICT)
        DrawText(revealed ? "Review the trace or reset to try again."
                          : "Choose an answer before playing the trace.",
                 52, ROW_Y + 18, FS_SMALL, UI_MUTED);
    float bw = (RIGHT.width - 3 * 14) / 4;
    if (ui_button((Rectangle){ RIGHT.x, ROW_Y, bw, ROW_H },
                  a->playing ? "Pause" : "Play", live, false))
        a->playing = !a->playing;
    if (ui_button((Rectangle){ RIGHT.x + (bw + 14), ROW_Y, bw, ROW_H }, "Step",
                  live, false)) {
        a->playing = false;
        Step(a);
    }
    if (ui_button((Rectangle){ RIGHT.x + 2 * (bw + 14), ROW_Y, bw, ROW_H },
                  "Back", a->cursor > 0, false))
        Back(a);
    if (ui_button((Rectangle){ RIGHT.x + 3 * (bw + 14), ROW_Y, bw, ROW_H },
                  "Reset", true, false)) {
        if (a->mode == MODE_BUG) a->scenario = SOO_BOUNDS;
        Load(a);
    }
    DrawText("Space: play/pause    Right: step    Left: back    R: reset    "
             "1-6: level    A/B/C: answer    S: speed",
             45, FOOT_Y, FS_SMALL, UI_MUTED);
}

void arrays_draw(ArraysScreen *a)
{
    static const char *const subtitles[4] = {
        "WRITE C CODE TO REPAIR THE CARDS", "PREDICT THE RESULT",
        "EXPLORE SAMPLE TRACES", "FIND THE BOUNDS BUG"
    };
    ui_background();
    ui_header("Arrays", subtitles[a->mode]);
    draw_header_buttons(a);
    if (a->mode == MODE_CODE) draw_code_mode(a);
    else draw_sample_mode(a);
    ui_text_right(TextFormat("Speed %.2fs / step", a->interval), 1875, FOOT_Y,
                  FS_SMALL, UI_MUTED);
}

/* ========================================================================
 * Screenshot scripting / 스크린샷 스크립트
 * ====================================================================== */

void arrays_qa(ArraysScreen *a, const char *mode, int level, int steps,
               int variant)
{
    ArraysMode m = MODE_CODE;
    if (strcmp(mode, "predict") == 0) m = MODE_PREDICT;
    else if (strcmp(mode, "explore") == 0) m = MODE_EXPLORE;
    else if (strcmp(mode, "bug") == 0) m = MODE_BUG;
    set_mode(a, m);
    if (m != MODE_BUG) set_level(a, level);

    if (m == MODE_CODE) {
        const char *src = array_example_solution(a->level);
        if (variant == 1)
            src = "void run(void) {\n"
                  "    for (int i = 0; i <= N; ++i) {\n"
                  "        if (cards[i] == 1)\n"
                  "            cards[i] = 0;\n"
                  "    }\n"
                  "}\n";
        else if (variant == 2)
            src = "void run(void) {\n"
                  "    for (int i = 0; i < N; ++i) {\n"
                  "        if (card[i] == 1)\n"
                  "            cards[i] = 0\n"
                  "    }\n"
                  "}\n";
        if (variant != 3) ed_set_text(a->ed, src, true);
        code_watch_edits(a);
        if (variant == 2) {
            code_prepare(a);
        } else if (variant != 3) {
            code_prepare(a);
            for (int k = 0; k < steps; k++) code_step(a);
        }
        a->ed->focused = variant != 1;
        code_update_markers(a);
    } else if (m == MODE_EXPLORE) {
        if (variant >= 0 && variant <= 3) {
            a->scenario = (SooScenario)variant;
            Load(a);
        }
        for (int k = 0; k < steps; k++) Step(a);
    } else {
        Answer(a, variant);
        a->playing = false;
        for (int k = 0; k < steps; k++) Step(a);
    }
}
